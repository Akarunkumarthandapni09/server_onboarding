# Server Onboarding with Ansible

This repository contains an Ansible-based workflow for standard Linux server onboarding and operational baseline setup. It is designed to automate common tasks such as time synchronization, DNS configuration, user and group creation, disk checks, patching, monitoring, backup setup, and vulnerability scanning.

## Overview

The project is organized around a central playbook that imports a sequence of role-based tasks and a simple inventory that points to the target Linux host.

## Repository structure

```text
.
├── ansible.cfg
├── backups/
├── inventory/
│   ├── group_vars/
│   │   ├── dc1.yml
│   │   └── linux.yml
│   └── local.ini
├── playbook/
│   ├── ad_join.yml
│   ├── agents.yml
│   ├── backup.yml
│   ├── cmdb_discovery.yml
│   ├── disk.yml
│   ├── dns.yml
│   ├── group.yml
│   ├── master.yml
│   ├── monitoring.yml
│   ├── ntp.yml
│   ├── patching.yml
│   ├── reboot_login_test.yml
│   ├── service_accounts.yml
│   ├── terraform_setup.yml
│   ├── users.yml
│   └── vulnerability_scan.yml
├── roles/
│   ├── ad_joins/
│   ├── agents/
│   ├── backup/
│   ├── cmdb_discovery/
│   ├── disk/
│   ├── dns/
│   ├── groups/
│   ├── monitoring/
│   ├── ntp/
│   ├── patching/
│   ├── reboot_login_test/
│   ├── service_accounts/
│   ├── terraform/
│   ├── users/
│   └── vulnerability_scan/
├── vulnerability_report.txt
└── README.md
```

## Key configuration

### Ansible configuration
The root `ansible.cfg` sets the inventory path and role path:

```ini
[defaults]
inventory = inventory/local.ini
roles_path = ./roles
```

### Inventory
The inventory file contains the Linux host target and SSH settings:

```ini
[linux]
azure-vm ansible_host=104.211.219.15

[terraform]
azure-vm

[linux:vars]
ansible_user=azureuser
ansible_ssh_private_key_file=~/.ssh/rg-ansible-lab_key.pem
```

Update this file to match your target host, SSH user, and key path before running the automation.

## Included playbooks

The main workflow is defined in `playbook/master.yml` and imports the following tasks:

- `ntp.yml` - time sync configuration
- `dns.yml` - DNS setup
- `group.yml` - group management
- `users.yml` - user creation and setup
- `disk.yml` - disk checks or configuration
- `service_accounts.yml` - service account creation
- `agents.yml` - agent installation
- `backup.yml` - backup configuration
- `patching.yml` - package updates and checks
- `reboot_login_test.yml` - reboot verification
- `vulnerability_scan.yml` - security scan with Nmap and Lynis
- `monitoring.yml` - monitoring checks
- `cmdb_discovery.yml` - CMDB-related discovery tasks

## Prerequisites

Before running this project, ensure the following are available:

- Ansible installed on the control machine
- SSH access to the target Linux server
- A valid private key configured in the inventory
- Appropriate permissions to create users, install packages, and manage system services

## Running the automation

### Verify connectivity

```bash
ansible all -i inventory/local.ini -m ping
```

### Run the full onboarding workflow

```bash
ansible-playbook -i inventory/local.ini playbook/master.yml
```

### Run a single task group

```bash
ansible-playbook -i inventory/local.ini playbook/patching.yml
ansible-playbook -i inventory/local.ini playbook/users.yml
ansible-playbook -i inventory/local.ini playbook/vulnerability_scan.yml
```

### Dry run

For a no-change preview, use check mode:

```bash
ansible-playbook -i inventory/local.ini playbook/master.yml --check --diff
```

## Variables and customization

The group variables under `inventory/group_vars/` define server-level settings such as:

```yaml
dns_servers:
  - 1.1.1.1
  - 8.8.8.8

location: Azure-South-India
```

You can customize these values based on your environment and datacenter standards.

## Security and operational notes

- This automation changes system configuration; validate it in a test or staging environment first.
- Patching tasks may install updates and trigger a reboot.
- Vulnerability scan results are written to the scan report and may be reviewed in `vulnerability_report.txt`.
- Review the role tasks before running them in production to avoid unexpected side effects.

## Typical use case

This repository is useful for bootstrapping a newly provisioned Azure Linux VM into a managed baseline state, including:

- server hardening fundamentals
- patch hygiene
- identity and access readiness
- service visibility and monitoring
- backup readiness
- security reporting

## Future improvements

Potential follow-ups for this project include:

- splitting environment-specific inventories for dev/stage/prod
- adding secrets management instead of hardcoded SSH paths
- adding role-level documentation per task group
- consolidating repeated tasks into more modular variables
- adding CI validation for syntax checks and linting

## License

This project is intended for internal environment automation and operational use. Add a license file if you plan to distribute or share it outside your organization.
