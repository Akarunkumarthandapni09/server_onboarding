#!/bin/bash

set -e

AGENT_DIR="/opt/server-agents"

echo "Creating simulated enterprise agents..."

mkdir -p "$AGENT_DIR"

create_agent_service() {
    AGENT_NAME="$1"

    cat > "/etc/systemd/system/${AGENT_NAME}-agent.service" <<EOF
[Unit]
Description=Simulated ${AGENT_NAME} Enterprise Agent
After=network.target

[Service]
Type=simple
ExecStart=/bin/bash -c 'while true; do sleep 3600; done'
Restart=always

[Install]
WantedBy=multi-user.target
EOF

    echo "Created ${AGENT_NAME}-agent.service"
}

create_agent_service "splunk"
create_agent_service "logicmonitor"
create_agent_service "illumio"
create_agent_service "defender"
create_agent_service "tenable"

systemctl daemon-reload

echo "All simulated agent services created successfully."